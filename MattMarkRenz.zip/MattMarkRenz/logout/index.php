<?php
session_start();
session_unset();
session_destroy();

header("location:../login"); 
// Relative Paths: Relative paths indicate a location relative to the current
//  directory where the script is being executed.