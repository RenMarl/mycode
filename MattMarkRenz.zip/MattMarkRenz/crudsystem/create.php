<?php
// Include config file
require_once("../_includes/connection.php");
 
// Define variables and initialize with empty values
$name = $email = $phone = $message = "";
$name_err = $email_err = $phone_err = $message_err = "";
$database = new Connection();
$db = $database->open();
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate name
    $input_name = trim($_POST["name"]);
    if(empty($input_name)){
        $name_err = "Please enter a name.";
    } elseif(!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $name_err = "Please enter a valid name.";
    } else{
        $name = $input_name;
    }
    
    // Validate email
    $input_email = trim($_POST["email"]);
    if(empty($input_email)){
        $email_err = "Please enter an email.";     
    } else{
        $email = $input_email;
    }
    

    // Validate phone
    $input_phone = trim($_POST["phone"]);
    if(empty($input_phone)){
        $phone_err = "Please enter the phone No.";     
    } elseif(!ctype_digit($input_phone)){
        $phone_err = "Please enter integer values only";
    } else{
        $phone = $input_phone;
    }

    // Validate message
    $input_message = trim($_POST["message"]);
    if(empty($input_message)){
        $message_err = "Please enter the message.";     
    } else{
        $message = $input_message;
    }
    
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($email_err) && empty($phone_err) && empty($message_err)){
        // Prepare an insert statement
        
        $sql = "INSERT INTO mycontact (name, email, phone, message) VALUES (:name, :email, :phone, :message)";
 
        if($stmt = $db->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":name", $param_name);
            $stmt->bindParam(":email", $param_email);
            $stmt->bindParam(":phone", $param_phone);
            $stmt->bindParam(":message", $param_message);
            
            // Set parameters
            $param_name = $name;
            $param_email = $email;
            $param_phone = $phone;
            $param_message = $message;

            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Records created successfully. Redirect to landing page
                
                $result = $stmt->rowCount();
                
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        unset($stmt);
    }
    
    // Close connection
    unset($db);
}
?>
 
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
    <div class="wrapper">
        
            <div class="row">
                <div class="col-md-12">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Contact Us</h2>
                    <h3 class="section-subheading text-muted">*You may enter the details below for your payment inquiries ↓ <br /> Payment can be done through third party platforms (e.g. Gcash, Paypal etc...)</h3>
                    <h4 class="section-subheading text-muted">*Guarantee: Install First before payment!</h4>
                </div>
                    <form action="<?php  echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    
                        <div class="form-group">
                        <label style="color: white;">Name</label>
                            <input type="text" name="name" id = "name" placeholder="Your Name *" class="form-control <?php  echo (!empty($name_err)) ? 'is-invalid' : ''; ?>" value="<?php  echo $name; ?>">
                            <span class="invalid-feedback"><?php  echo $name_err;?></span>
                        </div>
                        <div class="form-group">
                        <label style="color: white;">Email</label>
                            <textarea name="email" id = "email" placeholder="Your Email *" class="form-control <?php  echo (!empty($email_err)) ? 'is-invalid' : ''; ?>"><?php  echo $email; ?></textarea>
                            <span class="invalid-feedback"><?php  echo $email_err;?></span>
                        </div>
                        <div class="form-group">
                        <label style="color: white;">Phone</label>
                            <input type="text" name="phone" id = "phone" placeholder="Your Phone *" class="form-control <?php  echo (!empty($phone_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $phone; ?>">
                            <span class="invalid-feedback"><?php echo $phone_err;?></span>
                        </div>
                        <div class="form-group">
                        <label style="color: white;">Message</label>
                            <textarea name="message" id = "message" placeholder="Your Message and Request*" class="form-control <?php echo (!empty($message_err)) ? 'is-invalid' : ''; ?>"><?php echo $message; ?></textarea>
                            <span class="invalid-feedback"><?php echo $message_err;?></span>
                        </div>
                        <div class="text-center">
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="../dashboard" class="btn btn-secondary ml-2">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>        
        </div>
    
