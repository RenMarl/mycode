<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.84.0">
    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/sign-in/">

    <!-- Bootstrap core CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="/docs/5.0/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
    <link rel="icon" href="/docs/5.0/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
    <link rel="icon" href="/docs/5.0/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
    <link rel="manifest" href="/docs/5.0/assets/img/favicons/manifest.json">
    <link rel="mask-icon" href="/docs/5.0/assets/img/favicons/safari-pinned-tab.svg" color="#7952b3">
    <link rel="icon" href="/docs/5.0/assets/img/favicons/favicon.ico">
    <meta name="theme-color" content="#7952b3">
    <title>Sign In</title>

    <style>
        html {
            height: 100%;
        }
        
        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            background: radial-gradient(darkgreen, orange);
        }
        
        .login-box {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 400px;
            padding: 40px;
            transform: translate(-50%, -50%);
            background: rgba(0, 0, 0, 0.5);
            box-sizing: border-box;
            box-shadow: 0 15px 25px rgba(0, 0, 0, 0.6);
            border-radius: 10px;
        }
        
        .login-box h2 {
            margin: 0 0 30px;
            padding: 0;
            color: #fff;
            text-align: center;
        }
        
        .login-box .user-box {
            position: relative;
        }
        
        .login-box .user-box input {
            width: 100%;
            padding: 10px 0;
            font-size: 16px;
            color: #fff;
            margin-bottom: 30px;
            outline: none;
            background: transparent;
        }
        
        .login-box .user-box label {
            position: absolute;
            top: 0;
            left: 0;
            padding: 10px 0;
            font-size: 16px;
            color: #fff;
            pointer-events: none;
            transition: 0.5s;
        }
        
        .login-box .user-box input:focus~label,
        .login-box .user-box input:valid~label {
            top: -20px;
            left: 0;
            color: darkorange;
            font-size: 12px;
        }
        
        .login-box form a {
            position: relative;
            display: inline-block;
            padding: 10px 20px;
            color:chocolate;
            font-size: 16px;
            text-decoration: none;
            text-transform: uppercase;
            overflow: hidden;
            transition: 0.5s;
            margin-top: 40px;
            letter-spacing: 4px;
        }
        
        .login-box a:hover {
            background: orange;
            color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 5px orange, 0 0 25px orange, 0 0 50px orange, 0 0 100px orange;
        }
        
        .login-box a span {
            position: absolute;
            display: block;
        }
        
        .login-box a span:nth-child(1) {
            top: 0;
            left: -100%;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, transparent, orange);
            animation: btn-anim1 3s linear infinite;
        }
        
        @keyframes btn-anim1 {
            0% {
                left: -100%;
            }
            50%,
            100% {
                left: 100%;
            }
        }
        
        .login-box a span:nth-child(2) {
            top: -100%;
            right: 0;
            width: 2px;
            height: 100%;
            background: linear-gradient(180deg, transparent, orange);
            animation: btn-anim2 2s linear infinite;
            animation-delay: 2.25s;
        }
        
        @keyframes btn-anim2 {
            0% {
                top: -100%;
            }
            50%,
            100% {
                top: 100%;
            }
        }
        
        .login-box a span:nth-child(3) {
            bottom: 0;
            right: 100%;
            width: 100%;
            height: 2px;
            background: linear-gradient(270deg, transparent, darkgreen);
            animation: btn-anim3 2s linear infinite;
            animation-delay: 2.5s;
        }
        
        @keyframes btn-anim3 {
            0% {
                right: -100%;
            }
            50%,
            100% {
                right: 100%;
            }
        }
        
        .login-box a span:nth-child(4) {
            bottom: -100%;
            left: 0;
            width: 2px;
            height: 100%;
            background: linear-gradient(360deg, transparent, darkgreen);
            animation: btn-anim4 3s linear infinite;
            animation-delay: 2.75s;
        }
        
        @keyframes btn-anim4 {
            0% {
                bottom: -100%;
            }
            50%,
            100% {
                bottom: 100%;
            }
        }
    </style>
    <link href="signin.css" rel="stylesheet">
</head>

<body>
    <div class="login-box">
        
    <?php
            if ($error == true) {
            ?>
                <div class="alert alert-danger mb-3" role="alert">
                    <?php echo $message; ?>
                </div>
            <?php
            }
            ?>
            <main class="form-signin">   
        <form method='post'>
        <h1 class="h3 mb-3 fw-normal" style="color: white" >Please Sign In</h1>
            <div class="user-box">
                <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@email.com">
                <!-- <input type="text" required> -->
                <!-- <label for=" ">Email address</label> -->
                <label for="floatingInput">Email address</label>
            </div>
            <div class="user-box">
                    <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password">
                    <label for="floatingPassword">Password</label>
                <!-- <input type="password" required>
                <label for="">Password</label> -->
            </div>
            <a href="">
                <span></span>
                <span></span>
                <button type="submit" name="submit" style="border: none;color: white; background-color: transparent;">Sign in</button>     
            </a>
            
            <p><a href="../register" class="link-success link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">Register?</a></p>
            <p class="mt-5 mb-3 text-muted">&copy; 2023–2024</p>

        </form>
    </div>

</body>

</html>