<?php
require("../_includes/connection.php");

// DEFAULT VARIABLE
$error = false;
$message = '';


function checkLogin($email, $pass)
{
    $database = new Connection();
    $db = $database->open();

    $stmt = $db->prepare('SELECT email, pass  FROM mytable WHERE email=:email');
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $res = $stmt->fetchAll();
    $rowCount = $stmt->rowCount();

    if($rowCount == 1)
    {

        $hash = $res[0]['pass'];
        if(password_verify($pass, $hash))
        {
            return 1;
        } else{
            return 0;
        }


    }
}
// $result check if the login is like to registered account // checklogin() is a funtion in php library
                                              // Query the database: It might build a query to search for a ---
                                              // user record where the email address matches the provided $email and password even hashed
                                              
                                              // Return a value:
                                              // If the email and password match, the function might return a value indicating successful login (e.g., true).
                                              // If the email and password don't match, it might return a value indicating failed login (e.g., false) or even an error message.
if(isset($_POST['submit']))
{
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $result = checkLogin($email,$pass);       

    if($result == 0)
    {
        $error = true;
        $message = "Invalid Email or Password!";     //checks the $result if false
    }
    if($result == 1)
    {
        session_start();
        $_SESSION['auth']  = true;          // if authenticate to true
        header('location:../dashboard');     // header heads to dashboard
    }



}

