<?php 
               if($result = $db->query($sql)){
                if($result->rowCount() > 0){
                    while($row = $result->fetch()){                  
                        echo '<a href="../crudsystem/delete.php?id='. $row['id'] .'" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>';
                }
                    unset($result);
            }
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
        
        // Close connection
        unset($db);

        ?>  