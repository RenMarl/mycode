<?php 
               if($result = $db->query($sql)){
                if($result->rowCount() > 0){
                    while($row = $result->fetch()){                  
                        echo '<a href="../crudsystem/update.php?id='. $row['id'] .'" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-pencil"></span></a>';
                }
                    unset($result);
            }
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
        
        // Close connection
        unset($db);

        ?>  