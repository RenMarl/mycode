<?php
    session_start();
    if(!isset($_SESSION['auth']))
{
    header('location:../login');
}
    
    
    include_once "header.php";
    include_once "../_includes/connection.php";
    $database = new Connection();
    $db = $database->open();
    $sql = "SELECT * FROM mycontact";

$portfolioModal1 = 'assets/img/portfolio/onehundred.jpg';
$portfolioModal2 = 'assets/img/portfolio/ulysses.jpg';
$portfolioModal3 = 'assets/img/portfolio/thegreatgatsby.jpg';
$portfolioModal4 = 'assets/img/portfolio/nineteen.jpg';
$portfolioModal5 = 'assets/img/portfolio/thecatcher.jpg';
$portfolioModal6 = 'assets/img/portfolio/insearch.jpg';
    
?>

    
    <body class="sb-nav-fixed">
        <!-- Navigation-->
        
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand" href="#page-top"><img src="assets/img/Book-Store-4-30-2024.png" alt="..." width="330" height="60" /></a>
            <!-- Sidebar Toggle-->
            <!-- <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button> -->
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-user-large"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="../crudsystem/index.php">Sent Messages</a></li>
                        <li><a class="dropdown-item" href="../register">Register</a></li>
                        <li><a class="dropdown-item" href="../logout/">Login</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item btn btn-success" href="../logout/">Logout</a></li>
                        
                    </ul>
                </li>
            </ul>
        </nav>

        <!-- Masthead-->
        <header class="masthead">
            
            <div class="container">
                <div class="masthead-subheading">Welcome!</div>
                <div class="masthead-heading text-uppercase">HI! ^_^</div>
                <?php echo '<a class="btn btn-primary btn-xl text-uppercase" href="#features">Explore</a>'; ?>
                
            </div>
            
        </header>
        
        <!-- Services-->
        
        <section class="page-section" id="features">
            
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Features/Keynote</h2>
                    <h3 class="section-subheading text-muted"></h3>
                </div>
                <div class="row text-center">
                    <div class="col-md-4">
                        <!-- <span class="fa-stack fa-3x">
                            <a href="#!"><img class="img-fluid d-block mx-auto" src="assets/img/logos/ebookicon.svg" alt="..." /></a>
                        </span> -->
                        <span class="fa-stack" style="font-size: 50px;">  <a href="https://en.wikipedia.org/wiki/Ebook"><img class="img-fluid d-block mx-auto" src="assets/img/logos/ebookicon.svg" alt="..." /></a>
                        </span>
                        <h4 class="my-4">E-book</h4>
                        <p class="text-muted">Shop and read whenever you are</p>
                    </div>
                    <div class="col-md-4">
                        <span class="fa-stack" style="font-size: 55px;">  <a href="https://en.wikipedia.org/wiki/Cross-platform_software"><img class="img-fluid d-block mx-auto" src="assets/img/logos/cross-platform.png" alt="..." /></a>
                        </span>
                        <h4 class="my-3">Cross Platform</h4>
                        <p class="text-muted">Use any type of device such as Android, Windows and Mac</p>
                    </div>
                    <div class="col-md-4">
                        <span class="fa-stack" style="font-size: 55px;">  <a href="https://www.trendesignbook.com/"><img class="img-fluid d-block mx-auto" src="assets/img/logos/trend.svg" alt="..." /></a>
                        </span>
                        <h4 class="my-3">Trend</h4>
                        <p class="text-muted">Keeps you up to date</p>
                    </div>
                </div>
            </div>
        </section>
        <!-- Portfolio Grid-->
        
        <section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Popular Categories</h2>
                    <h3 class="section-subheading text-muted">Trending Books</h3>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 1-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal1">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="<?php echo $portfolioModal1 ?>" alt="..." style="display: block; margin: 0 auto;" />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading">One Hundred Years of Solitude </div>
                                <div class="portfolio-caption-subheading text-muted">by Gabriel García Márquez</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 2-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal2">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="<?php echo $portfolioModal2 ?>" alt="..." style="display: block; margin: 0 auto;" />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading">Ulysses</div>
                                <div class="portfolio-caption-subheading text-muted">by James Joyce</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 3-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal3">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="<?php echo $portfolioModal3 ?>" alt="..." style="display: block; margin: 0 auto;"  />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading">The Great Gatsby </div>
                                <div class="portfolio-caption-subheading text-muted">by F. Scott Fitzgerald</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4 mb-lg-0">
                        <!-- Portfolio item 4-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal4">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="<?php echo $portfolioModal4 ?>" alt="..." style="display: block; margin: 0 auto;" />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading">Nineteen Eighty Four </div>
                                <div class="portfolio-caption-subheading text-muted">by George Orwell</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4 mb-sm-0">
                        <!-- Portfolio item 5-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal5">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="<?php echo $portfolioModal5 ?>" alt="..." style="display: block; margin: 0 auto;"  />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading">The Catcher in the Rye </div>
                                <div class="portfolio-caption-subheading text-muted">by J. D. Salinger</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <!-- Portfolio item 6-->
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-bs-toggle="modal" href="#portfolioModal6">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="<?php echo $portfolioModal6 ?>" alt="..." style="display: block; margin: 0 auto;"  />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading">In Search of Lost Time </div>
                                <div class="portfolio-caption-subheading text-muted">by Marcel Proust</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Portfolio Modal -->
        <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                    <!-- Project details-->
                                    <h2 class="text-uppercase">One Hundred Years of Solitude</h2>
                                    <p class="item-intro text-muted">by Gabriel García Márquez.</p>
                                    <img class="img-fluid d-block mx-auto" src="<?php echo $portfolioModal1 ?>" alt="..." />
                                    <p>This novel is a multi-generational saga that focuses on the Buendía family, who founded the fictional town of Macondo. It explores themes of love, loss, family, and the cyclical nature of history. The story is filled with magical realism, blending the supernatural with the ordinary, as it chronicles the family's experiences, including civil war, marriages, births, and deaths. The book is renowned for its narrative style and its exploration of solitude, fate, and the inevitability of repetition in history.</p>
                                    <ul class="list-inline">
                                        <li>
                                            <strong>Published:</strong>
                                            1967
                                        </li>
                                        <li>
                                            <strong>Type:</strong>
                                            Fiction

                                        </li>
                                    </ul>
                                    <button class="btn btn-primary btn-xl text-uppercase" data-bs-dismiss="modal" type="button">
                                        <i class="fas fa-xmark me-1"></i>
                                        Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio item 2 modal popup-->
        <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                    <!-- Project details-->
                                    <h2 class="text-uppercase">Ulysses</h2>
                                    <p class="item-intro text-muted">by James Joyce</p>
                                    <img class="img-fluid d-block mx-auto" src="<?php echo $portfolioModal2 ?>" alt="..." />
                                    <p>Set in Dublin, the novel follows a day in the life of Leopold Bloom, an advertising salesman, as he navigates the city. The narrative, heavily influenced by Homer's Odyssey, explores themes of identity, heroism, and the complexities of everyday life. It is renowned for its stream-of-consciousness style and complex structure, making it a challenging but rewarding read.</p>
                                    <ul class="list-inline">
                                        <li>
                                            <strong>Published:</strong>
                                            1922
                                        </li>
                                        <li>
                                            <strong>Type:</strong>
                                            Fiction
                                        </li>
                                    </ul>
                                    <button class="btn btn-primary btn-xl text-uppercase" data-bs-dismiss="modal" type="button">
                                        <i class="fas fa-xmark me-1"></i>
                                        Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio item 3 modal popup-->
        <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                    <!-- Project details-->
                                    <h2 class="text-uppercase">The Great Gatsby </h2>
                                    <p class="item-intro text-muted">by F. Scott Fitzgerald</p>
                                    <img class="img-fluid d-block mx-auto" src="<?php echo $portfolioModal3 ?>" alt="..." />
                                    <p>Set in the summer of 1922, the novel follows the life of a young and mysterious millionaire, his extravagant lifestyle in Long Island, and his obsessive love for a beautiful former debutante. As the story unfolds, the millionaire's dark secrets and the corrupt reality of the American dream during the Jazz Age are revealed. The narrative is a critique of the hedonistic excess and moral decay of the era, ultimately leading to tragic consequences.</p>
                                    <ul class="list-inline">
                                        <li>
                                            <strong>Published:</strong>
                                            1925
                                        </li>
                                        <li>
                                            <strong>Type:</strong>
                                            Fiction
                                        </li>
                                    </ul>
                                    <button class="btn btn-primary btn-xl text-uppercase" data-bs-dismiss="modal" type="button">
                                        <i class="fas fa-xmark me-1"></i>
                                        Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio item 4 modal popup-->
        <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                    <!-- Project details-->
                                    <h2 class="text-uppercase">Nineteen Eighty Four </h2>
                                    <p class="item-intro text-muted">by George Orwell</p>
                                    <img class="img-fluid d-block mx-auto" src="<?php echo $portfolioModal4 ?>" alt="..." />
                                    <p>Set in a dystopian future, the novel presents a society under the total control of a totalitarian regime, led by the omnipresent Big Brother. The protagonist, a low-ranking member of 'the Party', begins to question the regime and falls in love with a woman, an act of rebellion in a world where independent thought, dissent, and love are prohibited. The novel explores themes of surveillance, censorship, and the manipulation of truth.</p>
                                    <ul class="list-inline">
                                        <li>
                                            <strong>Published:</strong>
                                            1949
                                        </li>
                                        <li>
                                            <strong>Type:</strong>
                                            Fiction
                                        </li>
                                    </ul>
                                    <button class="btn btn-primary btn-xl text-uppercase" data-bs-dismiss="modal" type="button">
                                        <i class="fas fa-xmark me-1"></i>
                                        Close 
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio item 5 modal popup-->
        <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                    <!-- Project details-->
                                    <h2 class="text-uppercase">The Catcher in the Rye </h2>
                                    <p class="item-intro text-muted">by J. D. Salinger</p>
                                    <img class="img-fluid d-block mx-auto" src="<?php echo $portfolioModal5 ?>" alt="..." />
                                    <p>The novel follows the story of a teenager named Holden Caulfield, who has just been expelled from his prep school. The narrative unfolds over the course of three days, during which Holden experiences various forms of alienation and his mental state continues to unravel. He criticizes the adult world as "phony" and struggles with his own transition into adulthood. The book is a profound exploration of teenage rebellion, alienation, and the loss of innocence.</p>
                                    <ul class="list-inline">
                                        <li>
                                            <strong>Published:</strong>
                                            1951
                                        </li>
                                        <li>
                                            <strong>Type:</strong>
                                            Fiction
                                        </li>
                                    </ul>
                                    <button class="btn btn-primary btn-xl text-uppercase" data-bs-dismiss="modal" type="button">
                                        <i class="fas fa-xmark me-1"></i>
                                        Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio item 6 modal popup-->
        <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                    <!-- Project details-->
                                    <h2 class="text-uppercase">In Search of Lost Time </h2>
                                    <p class="item-intro text-muted">by Marcel Proust</p>
                                    <img class="img-fluid d-block mx-auto" src="<?php echo $portfolioModal6 ?>" alt="..." />
                                    <p>This renowned novel is a sweeping exploration of memory, love, art, and the passage of time, told through the narrator's recollections of his childhood and experiences into adulthood in the late 19th and early 20th century aristocratic France. The narrative is notable for its lengthy and intricate involuntary memory episodes, the most famous being the "madeleine episode". It explores the themes of time, space and memory, but also raises questions about the nature of art and literature, and the complex relationships between love, sexuality, and possession.</p>
                                    <ul class="list-inline">
                                        <li>
                                            <strong>Published:</strong>
                                            1913
                                        </li>
                                        <li>
                                            <strong>Type:</strong>
                                            Fiction
                                        </li>
                                    </ul>
                                    <button class="btn btn-primary btn-xl text-uppercase" data-bs-dismiss="modal" type="button">
                                        <i class="fas fa-xmark me-1"></i>
                                        Close 
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About-->
        
        <section class="page-section" id="about">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">The Timeline of Books</h2>
                    <h3 class="section-subheading text-muted">For The Information(FTI)*</h3>
                </div>
                <ul class="timeline">
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/9.jpg" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Early Forms</h4>
                                <h4 class="subheading">(Before 100 AD)</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">3500 BC: Early humans etch symbols onto clay tablets, considered the earliest form of writing.
2400 BC: Egyptians develop papyrus scrolls, made from the papyrus plant, for recording information.
600 BC: Standardized writing systems like the Phoenician alphabet emerge, facilitating the spread of written communication.
500-200 BC: Parchment, a more durable writing material made from animal skins, becomes popular.</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/6.jpg" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Medieval Developments </h4>
                                <h4 class="subheading"> (100 AD - 1450 AD)</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">105 AD: Paper is invented in China, revolutionizing bookmaking due to its affordability and ease of production.
400-600 AD: Illustrations are increasingly incorporated into books.
868 AD: The Diamond Sutra, believed to be the world's first dated printed book, is created in China using woodblock printing.</p></div>
                        </div>
                    </li>
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/7.jpg" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>The Printing Revolution</h4>
                                <h4 class="subheading">(1450 AD - 1800 AD)</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">1041-1230 AD: Bi Sheng in China invents movable type printing, using individual characters to create reusable printing blocks.
1250 AD: Block printing is developed in Egypt.
1439-1450 AD: Johannes Gutenberg invents the movable type printing press in Europe, significantly increasing book production and literacy rates.
1455 AD: The Gutenberg Bible, one of the first major works printed with Gutenberg's press, is published.
1490-1500 AD: The printing revolution explodes in Europe, leading to a wider dissemination of knowledge and ideas.
1501 AD: The first known precursor to the modern paperback book is published in Germany.
1639-1640 AD: The Bay Psalm Book becomes the first book printed in what is now the United States.</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/8.jpg" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Modern Era</h4>
                                <h4 class="subheading">(1800 AD - Present)</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">1744 AD: The discovery of chlorine bleaching allows for mass production of white paper.
1832 AD: Book sleeves are introduced to protect books from dust and damage.
19th & 20th Centuries: Advancements in printing technology, paper production, and binding methods lead to the development of modern book formats like hardcovers, paperbacks, and mass-market paperbacks.
20th & 21st Centuries: The rise of e-readers and audiobooks introduces new ways to access and consume books.</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image">
                            <h4>
                                Keeping
                                <br />
                                You
                                <br />
                                Busy!
                            </h4>
                        </div>
                    </li>
                </ul>
            </div>
        </section>
       
        <!-- Clients-->
        <div class="py-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-3 col-sm-6 my-3">
                        <a href="#!"><img class="img-fluid img-brand d-block mx-auto" src="assets/img/logos/microsoft.svg" alt="..." aria-label="Microsoft Logo" /></a>
                    </div>
                    <div class="col-md-3 col-sm-6 my-3">
                        <a href="#!"><img class="img-fluid img-brand d-block mx-auto" src="assets/img/logos/google.svg" alt="..." aria-label="Google Logo" /></a>
                    </div>
                    <div class="col-md-3 col-sm-6 my-3">
                        <a href="#!"><img class="img-fluid img-brand d-block mx-auto" src="assets/img/logos/facebook.svg" alt="..." aria-label="Facebook Logo" /></a>
                    </div>
                    <div class="col-md-3 col-sm-6 my-3">
                        <a href="#!"><img class="img-fluid img-brand d-block mx-auto" src="assets/img/logos/ibm.svg" alt="..." aria-label="IBM Logo" /></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Profile-->
        <section class="page-section" id="profile">
           <!-- Put the code here -->
           
           <!-- Put the code here -->
        </section>
         <!-- Contact -->
         <section class="page-section bg-light" id="contact"> 
         <div class="container"> 
                <!-- Change -->
                <?php include "../crudsystem/create.php"; ?>
                <!-- Change -->
            </div>
           <div></div>
        </section>
        <!-- Footer-->
        <footer class="footer py-4">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 text-lg-start">Copyright by &copy; Matt, Mark, Renz</div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <a class="btn btn-dark btn-social mx-2" href="https://twitter.com/?lang=en" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="https://getbootstrap.com/docs/5.0/getting-started/introduction/" aria-label="Bootstrap"><i class="fab fa-bootstrap"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="https://www.linkedin.com/login" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <a class="link-dark text-decoration-none me-3" href="https://policies.google.com/privacy?hl=en-US">Privacy Policy</a>
                        <a class="link-dark text-decoration-none" href="https://policies.google.com/privacy?hl=en-US">Terms of Use</a>
                    </div>
                    
                </div>
                <!-- <a href="../logout/" class="position-relative py-2 px-4 text-bg-secondary border border-secondary rounded-pill">Logout
                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="position-absolute top-100 start-50 translate-middle mt-1" 
                    fill="var(--bs-secondary)" xmlns="http://www.w3.org/2000/svg"><path 
                    d="M7.247 11.14L2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z"/></svg></a> -->
            </div>
            
            
        </footer>
      
        <!-- Bootstrap core JS-->
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
