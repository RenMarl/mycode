<?php

require("../_includes/connection.php");

// PAGE VARIABLES
$error = false;
$info = false;
$message = "";



if(isset($_POST['submit']))
{
    $email =  $_POST['email'];
    $pass1 = $_POST['pass1'];
    $pass2 = $_POST['pass2'];
    $name = $_POST['name'];


    if($pass1 != $pass2)
    {
        $error = true;               // Confirm Password
        $message =  "Password Did not Match!";
        exit();
    }

    $result = insertdata($email,$pass1,$name);

    if($result == 1)
    {
        $info = true;
        $message = "Sucessfully registered";
    }

}



function insertdata($email,$pass1, $name)
{

    
    $database = new Connection();
    $db = $database->open();

    $account_type = 'client';
    $account_status = 'active';
    $pass = password_hash($pass1, PASSWORD_DEFAULT);


    $stmt = $db->prepare('INSERT INTO mytable (email, pass, account_type, account_status, name)
                            VALUES (:email, :pass, :account_type, :account_status, :name)');
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':pass', $pass);
    $stmt->bindParam(':account_type', $account_type);
    $stmt->bindParam(':account_status', $account_status);
    $stmt->bindParam(':name', $name);
    $stmt->execute();
    $rowCount = $stmt->rowCount();

    return $rowCount;


}