<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="dashboard/css/styles.css" rel="stylesheet" />
    <title>MattMarkRenz</title>
    <style>.button-container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh; /* Optional: Set the container height to fill the viewport */
    }</style>
</head>
<body>
    
    <div class="button-container">
        <a href="login/index.php" class="btn btn-primary btn-lg">Get Started</a>
        
    </div>
    <p class="mt-5 mb-3 text-muted">&copy; Use Brave or Microsoft Edge</p>
</body>
</html>